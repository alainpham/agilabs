DROP TABLE device_states;

DROP INDEX idx_device_states_tenant;
